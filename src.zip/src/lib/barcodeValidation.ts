export type BarcodeFormat = 'CODE128' | 'EAN13' | 'UPC'

export const barcodeFormats: Array<{ value: BarcodeFormat; label: string }> = [
  { value: 'CODE128', label: 'Code 128 (recommended)' },
  { value: 'EAN13', label: 'EAN-13' },
  { value: 'UPC', label: 'UPC-A' },
]

function validCheckDigit(value: string) {
  const digits = value.split('').map(Number)
  const expected = (10 - (digits.slice(0, -1).reduce((sum, digit, index) => sum + digit * ((digits.length - index) % 2 === 0 ? 3 : 1), 0) % 10)) % 10
  return expected === digits[digits.length - 1]
}

export function validateBarcode(value: string, format: BarcodeFormat): string | null {
  if (!value.trim()) return 'Barcode value is required.'
  if (format === 'CODE128') return /^[\x20-\x7E]+$/.test(value) ? null : 'Code 128 supports printable ASCII characters only.'
  if (format === 'EAN13') return /^\d{13}$/.test(value) && validCheckDigit(value) ? null : 'EAN-13 must contain 13 digits with a valid check digit.'
  return /^\d{12}$/.test(value) && validCheckDigit(value) ? null : 'UPC-A must contain 12 digits with a valid check digit.'
}

export function inferredBarcodeFormat(value: string): BarcodeFormat {
  if (!validateBarcode(value, 'EAN13')) return 'EAN13'
  if (!validateBarcode(value, 'UPC')) return 'UPC'
  return 'CODE128'
}
