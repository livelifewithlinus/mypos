import type { LucideIcon } from 'lucide-react'
import {
  BarChart3,
  Barcode,
  ScanLine,
  Boxes,
  LayoutDashboard,
  Package,
  ReceiptText,
  Settings,
  ShoppingCart,
  Users,
  X,
} from 'lucide-react'

export type PageKey = 'dashboard' | 'products' | 'barcode-generator' | 'barcode-scanner' | 'pos' | 'inventory' | 'sales' | 'reports' | 'users' | 'settings'

interface NavItem {
  label: string
  key: PageKey
  icon: LucideIcon
}

const navItems: NavItem[] = [
  { label: 'Dashboard', key: 'dashboard', icon: LayoutDashboard },
  { label: 'Products', key: 'products', icon: Package },
  { label: 'Barcode Generator', key: 'barcode-generator', icon: Barcode },
  { label: 'Barcode Scanner', key: 'barcode-scanner', icon: ScanLine },
  { label: 'POS', key: 'pos', icon: ShoppingCart },
  { label: 'Inventory', key: 'inventory', icon: Boxes },
  { label: 'Sales', key: 'sales', icon: ReceiptText },
  { label: 'Reports', key: 'reports', icon: BarChart3 },
  { label: 'Users', key: 'users', icon: Users },
  { label: 'Settings', key: 'settings', icon: Settings },
]

interface SidebarProps {
  activePage: PageKey
  isOpen: boolean
  onNavigate: (page: PageKey) => void
  onClose: () => void
}

export function Sidebar({ activePage, isOpen, onNavigate, onClose }: SidebarProps) {
  return (
    <>
      {isOpen && <button aria-label="Close navigation menu" className="fixed inset-0 z-30 bg-slate-950/30 lg:hidden" onClick={onClose} />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col bg-[#10231f] text-white shadow-xl transition-transform duration-200 lg:static lg:translate-x-0 lg:shadow-none ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex h-20 items-center justify-between border-b border-white/10 px-6">
          <button aria-label="Go to dashboard" className="flex items-center gap-3" onClick={() => onNavigate('dashboard')}>
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#e6b95b] text-lg font-bold text-[#10231f]">O</span>
            <span className="text-left">
              <span className="block text-sm font-bold tracking-[0.2em]">OPENPOS</span>
              <span className="block text-[11px] text-white/50">Simple. Powerful. Open source.</span>
            </span>
          </button>
          <button aria-label="Close navigation menu" className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white lg:hidden" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <nav aria-label="Main navigation" className="flex-1 space-y-1 px-4 py-6">
          <p className="px-3 pb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/35">Workspace</p>
          {navItems.map(({ label, key, icon: Icon }) => (
            <button
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-[#e6b95b] ${activePage === key ? 'bg-[#e6b95b] text-[#10231f]' : 'text-white/65 hover:bg-white/10 hover:text-white'}`}
              key={key}
              onClick={() => onNavigate(key)}
            >
              <Icon size={18} strokeWidth={activePage === key ? 2.5 : 2} />
              {label}
            </button>
          ))}
        </nav>

        <div className="border-t border-white/10 p-4">
          <div className="rounded-xl bg-white/5 p-4">
            <p className="text-xs font-semibold text-white/80">Phase 3 / Product Management</p>
            <p className="mt-1 text-xs leading-5 text-white/40">Products and categories are ready to manage.</p>
          </div>
        </div>
      </aside>
    </>
  )
}
