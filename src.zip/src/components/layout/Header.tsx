import { Bell, Menu, Search } from 'lucide-react'
import type { PageKey } from './Sidebar'

interface HeaderProps {
  activePage: PageKey
  onMenuClick: () => void
}

const pageTitles: Record<PageKey, string> = {
  dashboard: 'Dashboard',
  products: 'Products',
  'barcode-generator': 'Barcode Generator',
  'barcode-scanner': 'Barcode Scanner',
  pos: 'Point of Sale',
  inventory: 'Inventory',
  sales: 'Sales',
  reports: 'Reports',
  users: 'Users',
  settings: 'Settings',
}

export function Header({ activePage, onMenuClick }: HeaderProps) {
  return (
    <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white px-4 sm:px-8">
      <div className="flex items-center gap-3">
        <button aria-label="Open navigation menu" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#10231f] lg:hidden" onClick={onMenuClick}>
          <Menu size={22} />
        </button>
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">Workspace</p>
          <h1 className="text-xl font-bold text-slate-900">{pageTitles[activePage]}</h1>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <button aria-label="Search" className="hidden rounded-lg p-2 text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#10231f] sm:block">
          <Search size={19} />
        </button>
        <button aria-label="Notifications" className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#10231f]">
          <Bell size={19} />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-[#c56b45] ring-2 ring-white" />
        </button>
        <div className="hidden h-8 w-px bg-slate-200 sm:block" />
        <button className="flex items-center gap-2 rounded-lg p-1.5 pr-2 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-[#10231f]">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-[#d9e8e0] text-xs font-bold text-[#245545]">LM</span>
          <span className="hidden text-left sm:block">
            <span className="block text-sm font-semibold text-slate-800">Linus Muriuki</span>
            <span className="block text-[11px] text-slate-400">Administrator</span>
          </span>
        </button>
      </div>
    </header>
  )
}
