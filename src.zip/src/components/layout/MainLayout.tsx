import type { ReactNode } from 'react'
import { Header } from './Header'
import { Sidebar, type PageKey } from './Sidebar'

interface MainLayoutProps {
  activePage: PageKey
  children: ReactNode
  isSidebarOpen: boolean
  onNavigate: (page: PageKey) => void
  onMenuClick: () => void
  onCloseSidebar: () => void
}

export function MainLayout({ activePage, children, isSidebarOpen, onNavigate, onMenuClick, onCloseSidebar }: MainLayoutProps) {
  return (
    <div className="flex min-h-screen bg-[#f6f8f7]">
      <Sidebar activePage={activePage} isOpen={isSidebarOpen} onNavigate={onNavigate} onClose={onCloseSidebar} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header activePage={activePage} onMenuClick={onMenuClick} />
        <main className="flex-1 overflow-x-hidden px-4 py-6 sm:px-8 sm:py-8">{children}</main>
      </div>
    </div>
  )
}
