import { ArrowUpRight } from 'lucide-react'
import type { Sale } from '../../data/demoData'

interface RecentSalesProps {
  sales: Sale[]
}

export function RecentSales({ sales }: RecentSalesProps) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-5 sm:px-6">
        <div>
          <h2 className="font-semibold text-slate-900">Recent sales</h2>
          <p className="mt-1 text-xs text-slate-400">Your latest transactions</p>
        </div>
        <button className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-[#2f7659] hover:bg-[#e4f2eb] focus:outline-none focus:ring-2 focus:ring-[#10231f]">View all <ArrowUpRight size={14} /></button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[620px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-5 py-3 font-semibold sm:px-6">Transaction</th>
              <th className="px-5 py-3 font-semibold">Date & time</th>
              <th className="px-5 py-3 font-semibold">Items</th>
              <th className="px-5 py-3 font-semibold">Total</th>
              <th className="px-5 py-3 font-semibold">Payment</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sales.map((sale) => (
              <tr className="text-slate-600" key={sale.transactionNumber}>
                <td className="px-5 py-4 font-semibold text-slate-800 sm:px-6">{sale.transactionNumber}</td>
                <td className="px-5 py-4">{sale.dateTime}</td>
                <td className="px-5 py-4">{sale.items} items</td>
                <td className="px-5 py-4 font-semibold text-slate-800">{sale.total}</td>
                <td className="px-5 py-4"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">{sale.paymentMethod}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
