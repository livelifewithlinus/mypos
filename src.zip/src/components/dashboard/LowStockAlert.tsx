import { AlertTriangle, ArrowUpRight } from 'lucide-react'
import type { StockAlert } from '../../data/demoData'

interface LowStockAlertProps {
  items: StockAlert[]
}

export function LowStockAlert({ items }: LowStockAlertProps) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-5 sm:px-6">
        <div>
          <h2 className="font-semibold text-slate-900">Low stock alert</h2>
          <p className="mt-1 text-xs text-slate-400">Items that need replenishing</p>
        </div>
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#fff2d7] text-[#a96f16]"><AlertTriangle size={17} /></span>
      </div>
      <div className="divide-y divide-slate-100 px-5 sm:px-6">
        {items.map((item) => (
          <div className="flex items-center justify-between gap-4 py-4" key={item.sku}>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-800">{item.name}</p>
              <p className="mt-1 text-xs text-slate-400">SKU: {item.sku}</p>
            </div>
            <div className="shrink-0 text-right">
              <p className="text-sm font-bold text-[#c56b45]">{item.remaining} left</p>
              <p className="mt-1 text-[11px] text-slate-400">Reorder at {item.reorderLevel}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-100 px-5 py-4 sm:px-6">
        <button className="flex items-center gap-1 text-xs font-semibold text-[#2f7659] hover:underline focus:outline-none focus:ring-2 focus:ring-[#10231f]">Go to inventory <ArrowUpRight size={14} /></button>
      </div>
    </section>
  )
}
