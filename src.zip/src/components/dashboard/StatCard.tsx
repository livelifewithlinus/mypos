import { ArrowDownRight, ArrowUpRight, BarChart3, Boxes, CircleDollarSign, ShoppingBag } from 'lucide-react'
import type { Stat } from '../../data/demoData'

const icons = {
  green: CircleDollarSign,
  blue: ShoppingBag,
  amber: Boxes,
  slate: BarChart3,
}

const styles = {
  green: 'bg-[#e4f2eb] text-[#2f7659]',
  blue: 'bg-[#e6eef8] text-[#3c6594]',
  amber: 'bg-[#fff2d7] text-[#a96f16]',
  slate: 'bg-slate-100 text-slate-600',
}

export function StatCard({ label, value, detail, tone }: Stat) {
  const Icon = icons[tone]
  const isPositive = tone === 'green' || tone === 'blue'

  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        <span className={`grid h-10 w-10 place-items-center rounded-xl ${styles[tone]}`}><Icon size={19} /></span>
      </div>
      <p className="mt-5 text-2xl font-bold tracking-tight text-slate-900">{value}</p>
      <p className="mt-2 flex items-center gap-1 text-xs text-slate-400">
        {tone !== 'amber' && (isPositive ? <ArrowUpRight size={14} className="text-[#3d8b68]" /> : <ArrowDownRight size={14} />)}
        {detail}
      </p>
    </article>
  )
}
