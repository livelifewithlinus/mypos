import type { PageKey } from '../components/layout/Sidebar'

interface PlaceholderPageProps {
  page: Exclude<PageKey, 'dashboard'>
}

const pageCopy: Record<PlaceholderPageProps['page'], { description: string; phase: string }> = {
  'barcode-generator': { description: 'Barcode labels are available from the Barcode Generator.', phase: 'Phase 4' },
  'barcode-scanner': { description: 'Barcode scanning is available from the Barcode Scanner.', phase: 'Phase 5' },
  products: { description: 'Product management will be implemented in Phase 3.', phase: 'Phase 3' },
  pos: { description: 'Point-of-sale workflows will be implemented in Phase 4.', phase: 'Phase 4' },
  inventory: { description: 'Inventory management will be implemented in Phase 3.', phase: 'Phase 3' },
  sales: { description: 'Sales history will be implemented in Phase 4.', phase: 'Phase 4' },
  reports: { description: 'Reports and analytics will be implemented in Phase 5.', phase: 'Phase 5' },
  users: { description: 'User management will be implemented in Phase 6.', phase: 'Phase 6' },
  settings: { description: 'Application settings will be implemented in a future phase.', phase: 'Coming later' },
}

export function PlaceholderPage({ page }: PlaceholderPageProps) {
  const copy = pageCopy[page]
  const title = page.charAt(0).toUpperCase() + page.slice(1)

  return (
    <section className="mx-auto flex min-h-[calc(100vh-9rem)] max-w-5xl items-center justify-center">
      <div className="w-full rounded-2xl border border-slate-200 bg-white px-6 py-16 text-center shadow-[0_2px_10px_rgba(15,23,42,0.03)] sm:px-12">
        <span className="inline-flex rounded-full bg-[#e4f2eb] px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-[#2f7659]">{copy.phase}</span>
        <h2 className="mt-5 text-3xl font-bold tracking-tight text-slate-900">{title}</h2>
        <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-slate-500">{copy.description}</p>
      </div>
    </section>
  )
}
