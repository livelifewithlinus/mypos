import { ArrowUpRight, CalendarDays } from 'lucide-react'
import { useEffect, useState } from 'react'
import { LowStockAlert } from '../components/dashboard/LowStockAlert'
import { RecentSales } from '../components/dashboard/RecentSales'
import { StatCard } from '../components/dashboard/StatCard'
import { recentSales, stats, stockAlerts } from '../data/demoData'

export function Dashboard() {
  const [productStats, setProductStats] = useState<{ totalProducts: number; lowStockItems: number } | null>(null)

  useEffect(() => {
    fetch('/api/dashboard').then((response) => response.ok ? response.json() : Promise.reject()).then(setProductStats).catch(() => setProductStats(null))
  }, [])

  const displayStats = stats.map((stat) => {
    if (stat.label === 'Total products' && productStats) return { ...stat, value: String(productStats.totalProducts), detail: 'Products in your catalogue' }
    if (stat.label === 'Low stock items' && productStats) return { ...stat, value: String(productStats.lowStockItems), detail: 'Needs your attention' }
    return stat
  })
  return (
    <div className="mx-auto max-w-[1440px] space-y-7">
      <section className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm font-medium text-[#2f7659]">Tuesday, 22 September 2026</p>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">Good morning, Linus.</h2>
          <p className="mt-2 text-sm text-slate-500">Here is what is happening with your store today.</p>
        </div>
        <button className="flex w-fit items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-[#10231f]">
          <CalendarDays size={17} className="text-slate-400" /> This month <ArrowUpRight size={15} className="text-slate-400" />
        </button>
      </section>

      <section aria-label="Store summary" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {displayStats.map((stat) => <StatCard key={stat.label} {...stat} />)}
      </section>

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.55fr)_minmax(340px,1fr)]">
        <RecentSales sales={recentSales} />
        <LowStockAlert items={stockAlerts} />
      </section>
    </div>
  )
}
