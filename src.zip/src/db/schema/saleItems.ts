import { integer, sqliteTable } from 'drizzle-orm/sqlite-core'
import { products } from './products'
import { sales } from './sales'

export const saleItems = sqliteTable('sale_items', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  saleId: integer('sale_id').notNull().references(() => sales.id, { onDelete: 'cascade' }),
  productId: integer('product_id').notNull().references(() => products.id, { onDelete: 'restrict' }),
  quantity: integer('quantity').notNull(),
  unitPrice: integer('unit_price').notNull(),
  discount: integer('discount').notNull().default(0),
  subtotal: integer('subtotal').notNull(),
})
