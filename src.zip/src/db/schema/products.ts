import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core'
import { categories } from './categories'

export const products = sqliteTable('products', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  sku: text('sku').notNull().unique(),
  barcode: text('barcode').unique(),
  description: text('description'),
  price: integer('price').notNull(),
  costPrice: integer('cost_price').notNull(),
  stockQuantity: integer('stock_quantity').notNull().default(0),
  lowStockThreshold: integer('low_stock_threshold').notNull().default(5),
  categoryId: integer('category_id').references(() => categories.id, { onDelete: 'set null' }),
  imageUrl: text('image_url'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
})
