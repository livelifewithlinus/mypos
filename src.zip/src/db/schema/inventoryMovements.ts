import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core'
import { products } from './products'

export const inventoryMovementTypes = ['purchase', 'sale', 'adjustment', 'return', 'damaged'] as const
export type InventoryMovementType = (typeof inventoryMovementTypes)[number]

export const inventoryMovements = sqliteTable('inventory_movements', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  productId: integer('product_id').notNull().references(() => products.id, { onDelete: 'cascade' }),
  type: text('type').$type<InventoryMovementType>().notNull(),
  quantity: integer('quantity').notNull(),
  previousQuantity: integer('previous_quantity').notNull(),
  newQuantity: integer('new_quantity').notNull(),
  reason: text('reason'),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
})
