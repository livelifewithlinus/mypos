import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core'

export const paymentMethods = ['cash', 'mpesa', 'card', 'other'] as const
export type PaymentMethod = (typeof paymentMethods)[number]
export const saleStatuses = ['pending', 'completed', 'refunded', 'voided'] as const
export type SaleStatus = (typeof saleStatuses)[number]

export const sales = sqliteTable('sales', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  receiptNumber: text('receipt_number').notNull().unique(),
  subtotal: integer('subtotal').notNull(),
  discount: integer('discount').notNull().default(0),
  tax: integer('tax').notNull().default(0),
  total: integer('total').notNull(),
  paymentMethod: text('payment_method').$type<PaymentMethod>().notNull(),
  status: text('status').$type<SaleStatus>().notNull().default('pending'),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
})
