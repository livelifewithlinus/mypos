import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core'

export const userRoles = ['admin', 'manager', 'cashier'] as const
export type UserRole = (typeof userRoles)[number]

export const users = sqliteTable('users', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  email: text('email').unique(),
  role: text('role').$type<UserRole>().notNull().default('cashier'),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer('updated_at', { mode: 'timestamp_ms' }).notNull().$defaultFn(() => new Date()),
})
