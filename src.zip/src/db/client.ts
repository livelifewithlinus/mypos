import 'dotenv/config'
import { mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { createClient } from '@libsql/client'
import { drizzle } from 'drizzle-orm/libsql'
import * as schema from './schema/index'

const databaseUrl = process.env.DATABASE_URL ?? './.data/openpos.db'
export const databasePath = resolve(databaseUrl)

mkdirSync(dirname(databasePath), { recursive: true })

export const sqlite = createClient({ url: `file:${databasePath}` })
export const db = drizzle(sqlite, { schema })
