import 'dotenv/config'
import { db, sqlite } from './client'
import { categories } from './schema/categories'
import { products } from './schema/products'

const categorySeed = [
  { name: 'Groceries', description: 'Everyday pantry essentials' },
  { name: 'Dairy', description: 'Milk and chilled products' },
  { name: 'Beverages', description: 'Hot and cold drinks' },
] as const

const productSeed = [
  { name: 'Bread', sku: 'BRD-001', price: 6500, costPrice: 4800, stockQuantity: 24, lowStockThreshold: 8, category: 'Groceries' },
  { name: 'Milk', sku: 'MLK-001', price: 7500, costPrice: 5800, stockQuantity: 18, lowStockThreshold: 6, category: 'Dairy' },
  { name: 'Sugar', sku: 'SUG-001', price: 18000, costPrice: 14500, stockQuantity: 30, lowStockThreshold: 10, category: 'Groceries' },
  { name: 'Cooking Oil', sku: 'OIL-001', price: 42000, costPrice: 36000, stockQuantity: 12, lowStockThreshold: 5, category: 'Groceries' },
  { name: 'Rice', sku: 'RIC-001', price: 28000, costPrice: 23000, stockQuantity: 20, lowStockThreshold: 7, category: 'Groceries' },
] as const

for (const category of categorySeed) {
  await db.insert(categories).values(category).onConflictDoNothing({ target: categories.name })
}

const storedCategories = await db.select().from(categories)
const categoryIds = new Map(storedCategories.map((category) => [category.name, category.id]))

for (const product of productSeed) {
  const categoryId = categoryIds.get(product.category)
  if (!categoryId) throw new Error(`Missing category: ${product.category}`)
  await db.insert(products).values({
    name: product.name,
    sku: product.sku,
    price: product.price,
    costPrice: product.costPrice,
    stockQuantity: product.stockQuantity,
    lowStockThreshold: product.lowStockThreshold,
    categoryId,
  }).onConflictDoNothing({ target: products.sku })
}

const [storedCategoriesAfterSeed, storedProducts] = await Promise.all([
  db.select().from(categories),
  db.select().from(products),
])
console.log(`Seed complete: ${storedCategoriesAfterSeed.length} categories, ${storedProducts.length} products.`)
sqlite.close()
