import { useState } from 'react'
import { MainLayout } from './components/layout/MainLayout'
import type { PageKey } from './components/layout/Sidebar'
import { Dashboard } from './pages/Dashboard'
import { PlaceholderPage } from './pages/PlaceholderPage'
import { Products } from './pages/Products'
import { BarcodeGenerator } from './pages/BarcodeGenerator'
import { BarcodeScanner } from './pages/BarcodeScanner'
import { Pos } from './pages/Pos'
import type { Product } from './services/productService'

function App() {
  const [activePage, setActivePage] = useState<PageKey>('dashboard')
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [barcodeProduct, setBarcodeProduct] = useState<Product | null>(null)
  const [productBarcodePrefill, setProductBarcodePrefill] = useState('')

  const handleNavigate = (page: PageKey) => {
    setActivePage(page)
    setIsSidebarOpen(false)
  }

  return (
    <MainLayout
      activePage={activePage}
      isSidebarOpen={isSidebarOpen}
      onNavigate={handleNavigate}
      onMenuClick={() => setIsSidebarOpen(true)}
      onCloseSidebar={() => setIsSidebarOpen(false)}
    >
      {activePage === 'dashboard' ? <Dashboard /> : activePage === 'pos' ? <Pos /> : activePage === 'products' ? <Products initialBarcode={productBarcodePrefill} onOpenScanner={() => handleNavigate('barcode-scanner')} onOpenBarcode={(product) => { setBarcodeProduct(product); handleNavigate('barcode-generator') }} /> : activePage === 'barcode-generator' ? <BarcodeGenerator initialProduct={barcodeProduct} onClearInitial={() => setBarcodeProduct(null)} /> : activePage === 'barcode-scanner' ? <BarcodeScanner onViewProduct={() => handleNavigate('products')} onAddProduct={(barcode) => { setProductBarcodePrefill(barcode); handleNavigate('products') }} /> : <PlaceholderPage page={activePage} />}
    </MainLayout>
  )
}

export default App
