import { ApiError, type Product } from './productService'

export type ScannedProduct = Pick<Product, 'id' | 'name' | 'sku' | 'barcode' | 'price' | 'stockQuantity' | 'imageUrl' | 'categoryName'>

export async function lookupProductByBarcode(barcode: string): Promise<ScannedProduct> {
  const value = barcode.trim()
  if (!value) throw new ApiError('Enter or scan a barcode first.')
  const response = await fetch(`/api/products/barcode/${encodeURIComponent(value)}`)
  const payload = await response.json().catch(() => ({}))
  if (!response.ok) throw new ApiError(payload.error ?? 'Unable to look up this barcode.')
  return payload.data as ScannedProduct
}
