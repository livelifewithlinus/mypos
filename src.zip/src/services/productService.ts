export interface Category { id: number; name: string; description: string | null; isActive: boolean; createdAt: string; updatedAt: string }
export interface Product { id: number; name: string; sku: string; barcode: string | null; description: string | null; price: number; costPrice: number; stockQuantity: number; lowStockThreshold: number; categoryId: number | null; categoryName: string | null; imageUrl: string | null; isActive: boolean; createdAt: string; updatedAt: string }
export interface ProductInput { name: string; sku: string; barcode?: string | null; description?: string | null; categoryId?: number | null; price: number; costPrice: number; stockQuantity?: number; lowStockThreshold: number; imageUrl?: string | null; isActive: boolean }
export interface ProductFilters { search?: string; categoryId?: string; status?: string; stock?: string; page?: number }
export interface ProductResult { data: Product[]; meta: { page: number; pageSize: number; total: number; totalPages: number } }
export class ApiError extends Error { fields?: Record<string, string>; constructor(message: string, fields?: Record<string, string>) { super(message); this.fields = fields } }
async function request<T>(path: string, options?: RequestInit): Promise<T> { const response = await fetch(path, { headers: { 'content-type': 'application/json' }, ...options }); const payload = await response.json().catch(() => ({})); if (!response.ok) throw new ApiError(payload.error ?? 'Request failed.', payload.fields); return payload as T }
export const productService = {
  list(filters: ProductFilters = {}) { const query = new URLSearchParams({ pageSize: '20', status: filters.status ?? 'active', stock: filters.stock ?? 'all', page: String(filters.page ?? 1) }); if (filters.search) query.set('search', filters.search); if (filters.categoryId) query.set('categoryId', filters.categoryId); return request<ProductResult>(`/api/products?${query}`) },
  create(input: ProductInput) { return request<{ data: Product }>('/api/products', { method: 'POST', body: JSON.stringify(input) }) },
  update(id: number, input: ProductInput) { const { stockQuantity: _stockQuantity, ...editable } = input; return request<{ data: Product }>(`/api/products/${id}`, { method: 'PUT', body: JSON.stringify(editable) }) },
  deactivate(id: number) { return request<{ data: Product }>(`/api/products/${id}`, { method: 'DELETE' }) },
  saveBarcode(id: number, barcode: string, format: 'CODE128' | 'EAN13' | 'UPC') { return request<{ data: Product }>(`/api/products/${id}/barcode`, { method: 'PUT', body: JSON.stringify({ barcode, format }) }) },
}
export const categoryService = {
  list(includeInactive = true) { return request<{ data: Category[] }>(`/api/categories?includeInactive=${includeInactive}`) },
  create(input: Pick<Category, 'name' | 'description' | 'isActive'>) { return request<{ data: Category }>('/api/categories', { method: 'POST', body: JSON.stringify(input) }) },
  update(id: number, input: Pick<Category, 'name' | 'description' | 'isActive'>) { return request<{ data: Category }>(`/api/categories/${id}`, { method: 'PUT', body: JSON.stringify(input) }) },
  deactivate(id: number) { return request<{ data: Category }>(`/api/categories/${id}`, { method: 'DELETE' }) },
}
