import { ApiError } from './productService'
export type PaymentMethod = 'cash' | 'card' | 'other'
export interface CheckoutInput { items: Array<{ productId: number; quantity: number }>; discountType: 'fixed' | 'percentage'; discountValue: number; paymentMethod: PaymentMethod; amountReceived?: number }
export interface CompletedSale { id: number; receiptNumber: string; subtotal: number; discount: number; tax: number; total: number; paymentMethod: PaymentMethod; amountReceived: number | null; change: number }
export async function completeSale(input: CheckoutInput): Promise<CompletedSale> { const response = await fetch('/api/sales', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(input) }); const payload = await response.json().catch(() => ({})); if (!response.ok) throw new ApiError(payload.error ?? 'Unable to complete sale.'); return payload.data as CompletedSale }
