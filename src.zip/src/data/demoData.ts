export interface Stat {
  label: string
  value: string
  detail: string
  tone: 'green' | 'blue' | 'amber' | 'slate'
}

export interface Sale {
  transactionNumber: string
  dateTime: string
  items: number
  total: string
  paymentMethod: string
}

export interface StockAlert {
  name: string
  sku: string
  remaining: number
  reorderLevel: number
}

export const stats: Stat[] = [
  { label: 'Total sales', value: 'KSh 24,580', detail: '+12.5% from last month', tone: 'green' },
  { label: 'Total orders', value: '18', detail: '+8.2% from last month', tone: 'blue' },
  { label: 'Low stock items', value: '3', detail: 'Needs your attention', tone: 'amber' },
  { label: 'Total products', value: '42', detail: '4 added this month', tone: 'slate' },
]

export const recentSales: Sale[] = [
  { transactionNumber: '#OP-1048', dateTime: 'Today, 11:42 AM', items: 4, total: 'KSh 3,450', paymentMethod: 'M-Pesa' },
  { transactionNumber: '#OP-1047', dateTime: 'Today, 10:18 AM', items: 2, total: 'KSh 1,280', paymentMethod: 'Cash' },
  { transactionNumber: '#OP-1046', dateTime: 'Yesterday, 4:36 PM', items: 7, total: 'KSh 8,900', paymentMethod: 'Card' },
  { transactionNumber: '#OP-1045', dateTime: 'Yesterday, 2:05 PM', items: 3, total: 'KSh 2,750', paymentMethod: 'M-Pesa' },
]

export const stockAlerts: StockAlert[] = [
  { name: 'Arabica Coffee Beans', sku: 'COF-001', remaining: 2, reorderLevel: 10 },
  { name: 'Organic Green Tea', sku: 'TEA-014', remaining: 4, reorderLevel: 12 },
  { name: 'Almond Milk 1L', sku: 'MLK-008', remaining: 5, reorderLevel: 8 },
]
