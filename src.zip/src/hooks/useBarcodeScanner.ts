import { useEffect, useRef, useState } from 'react'

interface ScannerOptions { enabled: boolean; onScan: (barcode: string) => void; inputTimeoutMs?: number }

/** Captures rapid HID/keyboard scanner input while leaving focused form fields untouched. */
export function useBarcodeScanner({ enabled, onScan, inputTimeoutMs = 80 }: ScannerOptions) {
  const buffer = useRef(''); const startedAt = useRef(0); const lastKeyAt = useRef(0); const timer = useRef<number | undefined>(undefined); const callback = useRef(onScan); const [isScanning, setIsScanning] = useState(false)
  callback.current = onScan
  const clear = () => { buffer.current = ''; startedAt.current = 0; lastKeyAt.current = 0; if (timer.current) window.clearTimeout(timer.current); timer.current = undefined; setIsScanning(false) }
  useEffect(() => {
    if (!enabled) return clear
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null
      if (target?.matches('input, textarea, select, [contenteditable="true"]')) return
      const now = Date.now()
      if (event.key === 'Enter') { const value = buffer.current; const duration = now - startedAt.current; if (value.length >= 3 && duration <= Math.max(300, value.length * inputTimeoutMs)) callback.current(value); clear(); return }
      if (event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return
      if (lastKeyAt.current && now - lastKeyAt.current > inputTimeoutMs) buffer.current = ''
      if (!buffer.current) startedAt.current = now
      buffer.current = (buffer.current + event.key).slice(0, 128); lastKeyAt.current = now; setIsScanning(true)
      if (timer.current) window.clearTimeout(timer.current)
      timer.current = window.setTimeout(clear, inputTimeoutMs * 3)
    }
    window.addEventListener('keydown', handler)
    return () => { window.removeEventListener('keydown', handler); clear() }
  }, [enabled, inputTimeoutMs])
  return { isScanning, clear }
}
