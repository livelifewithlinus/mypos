import { useMemo, useState } from 'react'
import type { Product } from '../services/productService'

export interface CartItem { productId: number; productName: string; sku: string; barcode: string | null; unitPrice: number; quantity: number; stockQuantity: number }
export function useCart() {
  const [items, setItems] = useState<CartItem[]>([])
  const add = (product: Pick<Product, 'id' | 'name' | 'sku' | 'barcode' | 'price' | 'stockQuantity'>) => { let error = ''; setItems((current) => { const existing = current.find((item) => item.productId === product.id); if (existing) { if (existing.quantity >= product.stockQuantity) { error = `Only ${product.stockQuantity} units of ${product.name} are available.`; return current } return current.map((item) => item.productId === product.id ? { ...item, quantity: item.quantity + 1, stockQuantity: product.stockQuantity } : item) } if (product.stockQuantity < 1) { error = `${product.name} is out of stock.`; return current } return [...current, { productId: product.id, productName: product.name, sku: product.sku, barcode: product.barcode, unitPrice: product.price, quantity: 1, stockQuantity: product.stockQuantity }] }); return error }
  const setQuantity = (productId: number, quantity: number) => { let error = ''; setItems((current) => current.map((item) => { if (item.productId !== productId) return item; if (quantity < 1) return item; if (quantity > item.stockQuantity) { error = `Only ${item.stockQuantity} units of ${item.productName} are available.`; return item } return { ...item, quantity } })); return error }
  const remove = (productId: number) => setItems((items) => items.filter((item) => item.productId !== productId))
  const clear = () => setItems([])
  const subtotal = useMemo(() => items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0), [items])
  return { items, subtotal, add, setQuantity, remove, clear }
}
